import{i as D}from"../chunks/Ba4fzgfO.js";import{s as _,i as Ie,c as m,b as Se}from"../chunks/CX8Q0EHF.js";import{f as x,g as y,i as h,aT as Le,$ as Re,a0 as He,a2 as F,a3 as Oe,j as N,a4 as De,a6 as C,a5 as T,a7 as Fe,k as l,s as v,x as e,v as M,y as P,u as n,a9 as We,l as c,n as W,aa as I,D as qe}from"../chunks/CBDqqVMW.js";import{c as ge}from"../chunks/IzMG50tV.js";import{b as re}from"../chunks/oDpPjV-1.js";import{l as w,s as k,a as Ee,b as Ue}from"../chunks/DTG0HyhL.js";import{s as Ve}from"../chunks/C3Khc2s7.js";import{g as Xe}from"../chunks/CH_iu5NA.js";import{I as z}from"../chunks/D92jdmuk.js";const Je=()=>{const i=Ve;return{page:{subscribe:i.page.subscribe},navigating:{subscribe:i.navigating.subscribe},updated:i.updated}},Ye={subscribe(i){return Je().page.subscribe(i)}};function Ze(i,s){const p=w(s,["children","$$slots","$$events","$$legacy"]),g=[["path",{d:"m12 19-7-7 7-7"}],["path",{d:"M19 12H5"}]];z(i,k({name:"arrow-left"},()=>p,{get iconNode(){return g},children:(d,$)=>{var a=x(),u=y(a);_(u,s,"default",{}),h(d,a)},$$slots:{default:!0}}))}function te(i,s){const p=w(s,["children","$$slots","$$events","$$legacy"]),g=[["path",{d:"m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z"}],["circle",{cx:"12",cy:"12",r:"10"}]];z(i,k({name:"compass"},()=>p,{get iconNode(){return g},children:(d,$)=>{var a=x(),u=y(a);_(u,s,"default",{}),h(d,a)},$$slots:{default:!0}}))}function Ge(i,s){const p=w(s,["children","$$slots","$$events","$$legacy"]),g=[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"}]];z(i,k({name:"house"},()=>p,{get iconNode(){return g},children:(d,$)=>{var a=x(),u=y(a);_(u,s,"default",{}),h(d,a)},$$slots:{default:!0}}))}function Ke(i,s){const p=w(s,["children","$$slots","$$events","$$legacy"]),g=[["path",{d:"m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7"}],["rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"}]];z(i,k({name:"mail"},()=>p,{get iconNode(){return g},children:(d,$)=>{var a=x(),u=y(a);_(u,s,"default",{}),h(d,a)},$$slots:{default:!0}}))}function Qe(i,s){const p=w(s,["children","$$slots","$$events","$$legacy"]),g=[["path",{d:"M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384"}]];z(i,k({name:"phone"},()=>p,{get iconNode(){return g},children:(d,$)=>{var a=x(),u=y(a);_(u,s,"default",{}),h(d,a)},$$slots:{default:!0}}))}function er(i,s){const p=w(s,["children","$$slots","$$events","$$legacy"]),g=[["path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"}],["path",{d:"M21 3v5h-5"}],["path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"}],["path",{d:"M8 16H3v5"}]];z(i,k({name:"refresh-cw"},()=>p,{get iconNode(){return g},children:(d,$)=>{var a=x(),u=y(a);_(u,s,"default",{}),h(d,a)},$$slots:{default:!0}}))}function rr(i,s){const p=w(s,["children","$$slots","$$events","$$legacy"]),g=[["rect",{width:"20",height:"8",x:"2",y:"2",rx:"2",ry:"2"}],["rect",{width:"20",height:"8",x:"2",y:"14",rx:"2",ry:"2"}],["line",{x1:"6",x2:"6.01",y1:"6",y2:"6"}],["line",{x1:"6",x2:"6.01",y1:"18",y2:"18"}]];z(i,k({name:"server"},()=>p,{get iconNode(){return g},children:(d,$)=>{var a=x(),u=y(a);_(u,s,"default",{}),h(d,a)},$$slots:{default:!0}}))}function tr(i,s){const p=w(s,["children","$$slots","$$events","$$legacy"]),g=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"}]];z(i,k({name:"shield"},()=>p,{get iconNode(){return g},children:(d,$)=>{var a=x(),u=y(a);_(u,s,"default",{}),h(d,a)},$$slots:{default:!0}}))}function or(i,s){const p=w(s,["children","$$slots","$$events","$$legacy"]),g=[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"}],["path",{d:"M12 9v4"}],["path",{d:"M12 17h.01"}]];z(i,k({name:"triangle-alert"},()=>p,{get iconNode(){return g},children:(d,$)=>{var a=x(),u=y(a);_(u,s,"default",{}),h(d,a)},$$slots:{default:!0}}))}const ar=()=>{window.location.reload()};var sr=N(`<style>@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Inter:wght@300;400;500;600&display=swap');
    
    .architectural-grid {
      background-image: 
        linear-gradient(rgba(86, 170, 183, 0.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(86, 170, 183, 0.03) 1px, transparent 1px);
      background-size: 50px 50px;
      animation: grid-move 20s linear infinite;
    }
    
    @keyframes grid-move {
      0% { background-position: 0 0; }
      100% { background-position: 50px 50px; }
    }
    
    .blueprint-line {
      background: linear-gradient(90deg, transparent, var(--line-color, rgba(86, 170, 183, 0.3)), transparent);
      height: 1px;
      position: absolute;
      width: 100%;
    }
    
    .error-number {
      font-family: 'Playfair Display', serif;
      font-weight: 700;
      font-size: clamp(100px, 20vw, 200px);
      line-height: 0.8;
      color: transparent;
      -webkit-text-stroke: 2px var(--error-color);
      text-stroke: 2px var(--error-color);
      position: relative;
    }
    
    .error-number::before {
      content: attr(data-number);
      position: absolute;
      top: 0;
      left: 0;
      color: var(--error-color);
      opacity: 0.1;
      -webkit-text-stroke: 0;
      text-stroke: 0;
      z-index: -1;
    }
    
    .icon-decoration {
      position: absolute;
      opacity: 0.05;
      animation: rotate-slow 30s linear infinite;
    }
    
    @keyframes rotate-slow {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }
    
    .hover-lift {
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .hover-lift:hover {
      transform: translateY(-4px);
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    }
    
    .pulse-icon {
      animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
      0%, 100% { opacity: 0.5; transform: scale(1); }
      50% { opacity: 0.8; transform: scale(1.05); }
    }</style>`),nr=N('<div class="icon-decoration top-10 right-10"><!></div> <div class="icon-decoration bottom-10 left-10" style="animation-delay: -15s;"><!></div>',1),ir=N('<div class="icon-decoration top-10 right-10 pulse-icon"><!></div>'),lr=N('<div class="mt-4 p-4 bg-gray-50 rounded-lg max-w-md mx-auto"><p class="text-sm text-gray-500 font-mono break-words"> </p></div>'),cr=N('<a href="/projects" class="hover-lift group flex items-center gap-3 px-8 py-4 border-2 rounded-full font-medium transition-all duration-300"><span>View Our Projects</span> <!></a>'),dr=N('<button class="hover-lift group flex items-center gap-3 px-8 py-4 border-2 rounded-full font-medium transition-all duration-300"><!> <span>Try Again</span></button>'),vr=N('<p class="text-xs text-gray-400 mt-6"> </p>'),ur=N(`<div class="min-h-screen bg-white relative overflow-hidden flex items-center justify-center"><div class="architectural-grid absolute inset-0"></div> <div class="blueprint-line"></div> <div class="blueprint-line"></div> <div class="blueprint-line"></div> <!> <div class="relative z-10 text-center px-6 max-w-4xl mx-auto"><div class="mb-8"><h1 class="error-number"> </h1></div> <div class="space-y-6"><div class="flex justify-center mb-4"><div class="w-16 h-16 rounded-full flex items-center justify-center"><!></div></div> <div class="space-y-2"><h2 class="text-3xl md:text-4xl font-light text-gray-800 font-['Inter']"> </h2> <p class="text-lg text-gray-600 max-w-2xl mx-auto font-['Inter'] font-light"> </p> <!></div> <div class="flex items-center justify-center space-x-4 my-8"><div class="h-px bg-gradient-to-r from-transparent to-transparent w-24"></div> <div class="w-2 h-2 rounded-full"></div> <div class="h-px bg-gradient-to-r from-transparent to-transparent w-24"></div></div> <div class="flex flex-col sm:flex-row gap-4 justify-center items-center"><a href="/" class="hover-lift group flex items-center gap-3 px-8 py-4 text-white rounded-full font-medium transition-all duration-300"><!> <span>Back to Home</span></a> <!></div> <div class="mt-16 pt-8 border-t border-gray-200"><p class="text-sm text-gray-500 mb-4">Need immediate assistance?</p> <div class="flex flex-col sm:flex-row gap-6 justify-center items-center text-sm"><a href="tel:+6285383839900" class="flex items-center gap-2 text-gray-600 transition-colors"><!> <span>0853-8383-9900</span></a> <div class="hidden sm:block w-1 h-1 bg-gray-400 rounded-full"></div> <a href="mailto:2watujudesign@gmail.com" class="flex items-center gap-2 text-gray-600 transition-colors"><!> <span>2watujudesign@gmail.com</span></a></div> <!></div></div></div> <div class="absolute top-0 left-0 w-32 h-32 border-l-2 border-t-2 opacity-20"></div> <div class="absolute top-0 right-0 w-32 h-32 border-r-2 border-t-2 opacity-20"></div> <div class="absolute bottom-0 left-0 w-32 h-32 border-l-2 border-b-2 opacity-20"></div> <div class="absolute bottom-0 right-0 w-32 h-32 border-r-2 border-b-2 opacity-20"></div></div>`);function xr(i,s){Re(s,!1);const[p,g]=Ee(),d=()=>Ue(Ye,"$page",p),$=M(),a=M(),u=M(),r=M();let q=M(),E=M(),j=M();const oe={404:{icon:te,title:"Blueprint Not Found",description:"It seems the architectural plans you're looking for have been moved to another location. Let's help you find your way back.",color:"#56AAB7"},403:{icon:tr,title:"Access Restricted",description:"This area is under construction and requires special access. Please ensure you have the proper permissions.",color:"#F59E0B"},500:{icon:rr,title:"Foundation Issue",description:"We're experiencing some structural problems with our server. Our team is working to reinforce the foundation.",color:"#EF4444"},default:{icon:or,title:"Construction Zone",description:"We've encountered an unexpected issue. Our architectural team is investigating the problem.",color:"#6B7280"}};He(()=>{const t=Xe.timeline();t.fromTo(e(E),{opacity:0,scale:.8,y:50},{opacity:1,scale:1,y:0,duration:1,ease:"power4.out"}),e(j)&&e(j).children&&t.fromTo(e(j).children,{opacity:0,y:30},{opacity:1,y:0,duration:.8,stagger:.1,ease:"power3.out"},"-=0.5");const o=e(q).querySelectorAll(".blueprint-line");t.fromTo(o,{scaleX:0,transformOrigin:"left center"},{scaleX:1,duration:1,stagger:.2,ease:"power2.inOut"},"-=1")}),F(()=>d(),()=>{P($,d().status===404)}),F(()=>d(),()=>{P(a,d().status||500)}),F(()=>d(),()=>{var t;P(u,((t=d().error)==null?void 0:t.message)||"An unexpected error occurred")}),F(()=>e(a),()=>{P(r,oe[e(a)]||oe.default)}),Oe(),Ie();var S=ur();De(t=>{var o=sr();C(()=>We.title=`${e(a)??""} - ${e(r),n(()=>e(r).title)??""} | 2WATUJU Architecture`),h(t,o)});var ae=v(l(S),2),se=v(ae,2),ne=v(se,2),ie=v(ne,2);{var fe=t=>{var o=nr(),b=y(o),f=l(b);te(f,{size:200,get style(){return`color: ${e(r),n(()=>e(r).color)??""}`}}),c(b);var O=v(b,2),Be=l(O);te(Be,{size:150,get style(){return`color: ${e(r),n(()=>e(r).color)??""}`}}),c(O),h(t,o)},me=t=>{var o=ir(),b=l(o);ge(b,()=>e(r).icon,(f,O)=>{O(f,{size:150,get style(){return`color: ${e(r),n(()=>e(r).color)??""}`}})}),c(o),h(t,o)};D(ie,t=>{e($)?t(fe):t(me,!1)})}var U=v(ie,2),L=l(U),R=l(L),he=l(R,!0);c(R),c(L),re(L,t=>P(E,t),()=>e(E));var V=v(L,2),X=l(V),J=l(X),$e=l(J);ge($e,()=>e(r).icon,(t,o)=>{o(t,{size:32})}),c(J),c(X);var Y=v(X,2),Z=l(Y),be=l(Z,!0);c(Z);var G=v(Z,2),ye=l(G,!0);c(G);var _e=v(G,2);{var xe=t=>{var o=lr(),b=l(o),f=l(b,!0);c(b),c(o),C(()=>I(f,e(u))),h(t,o)};D(_e,t=>{!e($)&&e(u)&&t(xe)})}c(Y);var K=v(Y,2),le=l(K),ce=v(le,2),we=v(ce,2);c(K);var Q=v(K,2),H=l(Q),ke=l(H);Ge(ke,{size:20}),W(2),c(H);var ze=v(H,2);{var Te=t=>{var o=cr(),b=v(l(o),2);Ze(b,{size:20,class:"rotate-180"}),c(o),C(()=>m(o,`border-color: ${e(r),n(()=>e(r).color)??""}; color: ${e(r),n(()=>e(r).color)??""};`)),T("mouseenter",o,f=>{f.currentTarget.style.backgroundColor=e(r).color,f.currentTarget.style.color="white"}),T("mouseleave",o,f=>{f.currentTarget.style.backgroundColor="transparent",f.currentTarget.style.color=e(r).color}),h(t,o)},Ne=t=>{var o=dr();o.__click=[ar];var b=l(o);er(b,{size:20}),W(2),c(o),C(()=>m(o,`border-color: ${e(r),n(()=>e(r).color)??""}; color: ${e(r),n(()=>e(r).color)??""};`)),T("mouseenter",o,f=>{f.currentTarget.style.backgroundColor=e(r).color,f.currentTarget.style.color="white"}),T("mouseleave",o,f=>{f.currentTarget.style.backgroundColor="transparent",f.currentTarget.style.color=e(r).color}),h(t,o)};D(ze,t=>{e($)?t(Te):t(Ne,!1)})}c(Q);var de=v(Q,2),ee=v(l(de),2),A=l(ee),Me=l(A);Qe(Me,{size:16}),W(2),c(A);var B=v(A,4),Pe=l(B);Ke(Pe,{size:16}),W(2),c(B),c(ee);var Ae=v(ee,2);{var Ce=t=>{var o=vr(),b=l(o);c(o),C(f=>I(b,`Error Code: ${e(a)??""} | Timestamp: ${f??""}`),[()=>n(()=>new Date().toLocaleString())],qe),h(t,o)};D(Ae,t=>{e($)||t(Ce)})}c(de),c(V),re(V,t=>P(j,t),()=>e(j)),c(U);var ve=v(U,2),ue=v(ve,2),pe=v(ue,2),je=v(pe,2);c(S),re(S,t=>P(q,t),()=>e(q)),C(()=>{m(ae,`top: 20%; --line-color: ${e(r),n(()=>e(r).color)??""}30;`),m(se,`top: 50%; --line-color: ${e(r),n(()=>e(r).color)??""}30;`),m(ne,`top: 80%; --line-color: ${e(r),n(()=>e(r).color)??""}30;`),Se(R,"data-number",e(a)),m(R,`--error-color: ${e(r),n(()=>e(r).color)??""}`),I(he,e(a)),m(J,`background-color: ${e(r),n(()=>e(r).color)??""}20; color: ${e(r),n(()=>e(r).color)??""};`),I(be,(e(r),n(()=>e(r).title))),I(ye,(e(r),n(()=>e(r).description))),m(le,`background-image: linear-gradient(to right, transparent, ${e(r),n(()=>e(r).color)??""}, transparent);`),m(ce,`background-color: ${e(r),n(()=>e(r).color)??""};`),m(we,`background-image: linear-gradient(to right, transparent, ${e(r),n(()=>e(r).color)??""}, transparent);`),m(H,`background-color: ${e(r),n(()=>e(r).color)??""};`),m(A,`hover:color: ${e(r),n(()=>e(r).color)??""};`),m(B,`hover:color: ${e(r),n(()=>e(r).color)??""};`),m(ve,`border-color: ${e(r),n(()=>e(r).color)??""};`),m(ue,`border-color: ${e(r),n(()=>e(r).color)??""};`),m(pe,`border-color: ${e(r),n(()=>e(r).color)??""};`),m(je,`border-color: ${e(r),n(()=>e(r).color)??""};`)}),T("mouseenter",A,t=>t.currentTarget.style.color=e(r).color),T("mouseleave",A,t=>t.currentTarget.style.color="#4B5563"),T("mouseenter",B,t=>t.currentTarget.style.color=e(r).color),T("mouseleave",B,t=>t.currentTarget.style.color="#4B5563"),h(i,S),Fe(),g()}Le(["click"]);export{xr as component};
