import"../chunks/CWj6FrbW.js";import"../chunks/69_IOA4Y.js";import{a6 as _,a7 as y,$ as h,aP as Ie,Q as Re,R as Se,V as W,W as Le,X as T,Y as He,_ as C,Z as N,a0 as Oe,a4 as l,a3 as v,o as e,m as P,v as A,u as n,a8 as We,a5 as c,a1 as F,a9 as I,A as Fe}from"../chunks/4sdgcG-9.js";import{i as q}from"../chunks/RC3Db6EU.js";import{c as ge}from"../chunks/Df4A9IQs.js";import{s as x,i as qe,c as f,b as De}from"../chunks/BiWdm3Ln.js";import{b as re}from"../chunks/C3LVKDVP.js";import{l as w,s as k,a as Ee,b as Ve}from"../chunks/DATtISXp.js";import{s as Xe}from"../chunks/BxJnRmvy.js";import{I as z,g as Ue}from"../chunks/BeOD-hZK.js";const Ye=()=>{const i=Xe;return{page:{subscribe:i.page.subscribe},navigating:{subscribe:i.navigating.subscribe},updated:i.updated}},Ze={subscribe(i){return Ye().page.subscribe(i)}};function Je(i,s){const p=w(s,["children","$$slots","$$events","$$legacy"]),g=[["path",{d:"m12 19-7-7 7-7"}],["path",{d:"M19 12H5"}]];z(i,k({name:"arrow-left"},()=>p,{get iconNode(){return g},children:(d,$)=>{var a=_(),u=y(a);x(u,s,"default",{}),h(d,a)},$$slots:{default:!0}}))}function te(i,s){const p=w(s,["children","$$slots","$$events","$$legacy"]),g=[["path",{d:"m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z"}],["circle",{cx:"12",cy:"12",r:"10"}]];z(i,k({name:"compass"},()=>p,{get iconNode(){return g},children:(d,$)=>{var a=_(),u=y(a);x(u,s,"default",{}),h(d,a)},$$slots:{default:!0}}))}function Qe(i,s){const p=w(s,["children","$$slots","$$events","$$legacy"]),g=[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"}]];z(i,k({name:"house"},()=>p,{get iconNode(){return g},children:(d,$)=>{var a=_(),u=y(a);x(u,s,"default",{}),h(d,a)},$$slots:{default:!0}}))}function Ge(i,s){const p=w(s,["children","$$slots","$$events","$$legacy"]),g=[["path",{d:"m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7"}],["rect",{x:"2",y:"4",width:"20",height:"16",rx:"2"}]];z(i,k({name:"mail"},()=>p,{get iconNode(){return g},children:(d,$)=>{var a=_(),u=y(a);x(u,s,"default",{}),h(d,a)},$$slots:{default:!0}}))}function Ke(i,s){const p=w(s,["children","$$slots","$$events","$$legacy"]),g=[["path",{d:"M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384"}]];z(i,k({name:"phone"},()=>p,{get iconNode(){return g},children:(d,$)=>{var a=_(),u=y(a);x(u,s,"default",{}),h(d,a)},$$slots:{default:!0}}))}function er(i,s){const p=w(s,["children","$$slots","$$events","$$legacy"]),g=[["path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"}],["path",{d:"M21 3v5h-5"}],["path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"}],["path",{d:"M8 16H3v5"}]];z(i,k({name:"refresh-cw"},()=>p,{get iconNode(){return g},children:(d,$)=>{var a=_(),u=y(a);x(u,s,"default",{}),h(d,a)},$$slots:{default:!0}}))}function rr(i,s){const p=w(s,["children","$$slots","$$events","$$legacy"]),g=[["rect",{width:"20",height:"8",x:"2",y:"2",rx:"2",ry:"2"}],["rect",{width:"20",height:"8",x:"2",y:"14",rx:"2",ry:"2"}],["line",{x1:"6",x2:"6.01",y1:"6",y2:"6"}],["line",{x1:"6",x2:"6.01",y1:"18",y2:"18"}]];z(i,k({name:"server"},()=>p,{get iconNode(){return g},children:(d,$)=>{var a=_(),u=y(a);x(u,s,"default",{}),h(d,a)},$$slots:{default:!0}}))}function tr(i,s){const p=w(s,["children","$$slots","$$events","$$legacy"]),g=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"}]];z(i,k({name:"shield"},()=>p,{get iconNode(){return g},children:(d,$)=>{var a=_(),u=y(a);x(u,s,"default",{}),h(d,a)},$$slots:{default:!0}}))}function or(i,s){const p=w(s,["children","$$slots","$$events","$$legacy"]),g=[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"}],["path",{d:"M12 9v4"}],["path",{d:"M12 17h.01"}]];z(i,k({name:"triangle-alert"},()=>p,{get iconNode(){return g},children:(d,$)=>{var a=_(),u=y(a);x(u,s,"default",{}),h(d,a)},$$slots:{default:!0}}))}const ar=()=>{window.location.reload()};var sr=T(`<style>@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Inter:wght@300;400;500;600&display=swap');
    
    .architectural-grid {
      background-image: 
        linear-gradient(rgba(86, 170, 183, 0.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(86, 170, 183, 0.03) 1px, transparent 1px);
      background-size: 50px 50px;
      animation: grid-move 20s linear infinite;
    }
    
    @keyframes grid-move {
      0% { background-position: 0 0; }
      100% { background-position: 50px 50px; }
    }
    
    .blueprint-line {
      background: linear-gradient(90deg, transparent, var(--line-color, rgba(86, 170, 183, 0.3)), transparent);
      height: 1px;
      position: absolute;
      width: 100%;
    }
    
    .error-number {
      font-family: 'Playfair Display', serif;
      font-weight: 700;
      font-size: clamp(100px, 20vw, 200px);
      line-height: 0.8;
      color: transparent;
      -webkit-text-stroke: 2px var(--error-color);
      text-stroke: 2px var(--error-color);
      position: relative;
    }
    
    .error-number::before {
      content: attr(data-number);
      position: absolute;
      top: 0;
      left: 0;
      color: var(--error-color);
      opacity: 0.1;
      -webkit-text-stroke: 0;
      text-stroke: 0;
      z-index: -1;
    }
    
    .icon-decoration {
      position: absolute;
      opacity: 0.05;
      animation: rotate-slow 30s linear infinite;
    }
    
    @keyframes rotate-slow {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }
    
    .hover-lift {
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .hover-lift:hover {
      transform: translateY(-4px);
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    }
    
    .pulse-icon {
      animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
      0%, 100% { opacity: 0.5; transform: scale(1); }
      50% { opacity: 0.8; transform: scale(1.05); }
    }</style>`),nr=T('<div class="icon-decoration top-10 right-10"><!></div> <div class="icon-decoration bottom-10 left-10" style="animation-delay: -15s;"><!></div>',1),ir=T('<div class="icon-decoration top-10 right-10 pulse-icon"><!></div>'),lr=T('<div class="mt-4 p-4 bg-gray-50 rounded-lg max-w-md mx-auto"><p class="text-sm text-gray-500 font-mono break-words"> </p></div>'),cr=T('<a href="/projects" class="hover-lift group flex items-center gap-3 px-8 py-4 border-2 rounded-full font-medium transition-all duration-300"><span>View Our Projects</span> <!></a>'),dr=T('<button class="hover-lift group flex items-center gap-3 px-8 py-4 border-2 rounded-full font-medium transition-all duration-300"><!> <span>Try Again</span></button>'),vr=T('<p class="text-xs text-gray-400 mt-6"> </p>'),ur=T(`<div class="min-h-screen bg-white relative overflow-hidden flex items-center justify-center"><div class="architectural-grid absolute inset-0"></div> <div class="blueprint-line"></div> <div class="blueprint-line"></div> <div class="blueprint-line"></div> <!> <div class="relative z-10 text-center px-6 max-w-4xl mx-auto"><div class="mb-8"><h1 class="error-number"> </h1></div> <div class="space-y-6"><div class="flex justify-center mb-4"><div class="w-16 h-16 rounded-full flex items-center justify-center"><!></div></div> <div class="space-y-2"><h2 class="text-3xl md:text-4xl font-light text-gray-800 font-['Inter']"> </h2> <p class="text-lg text-gray-600 max-w-2xl mx-auto font-['Inter'] font-light"> </p> <!></div> <div class="flex items-center justify-center space-x-4 my-8"><div class="h-px bg-gradient-to-r from-transparent to-transparent w-24"></div> <div class="w-2 h-2 rounded-full"></div> <div class="h-px bg-gradient-to-r from-transparent to-transparent w-24"></div></div> <div class="flex flex-col sm:flex-row gap-4 justify-center items-center"><a href="/" class="hover-lift group flex items-center gap-3 px-8 py-4 text-white rounded-full font-medium transition-all duration-300"><!> <span>Back to Home</span></a> <!></div> <div class="mt-16 pt-8 border-t border-gray-200"><p class="text-sm text-gray-500 mb-4">Need immediate assistance?</p> <div class="flex flex-col sm:flex-row gap-6 justify-center items-center text-sm"><a href="tel:+6285383839900" class="flex items-center gap-2 text-gray-600 transition-colors"><!> <span>0853-8383-9900</span></a> <div class="hidden sm:block w-1 h-1 bg-gray-400 rounded-full"></div> <a href="mailto:2watujudesign@gmail.com" class="flex items-center gap-2 text-gray-600 transition-colors"><!> <span>2watujudesign@gmail.com</span></a></div> <!></div></div></div> <div class="absolute top-0 left-0 w-32 h-32 border-l-2 border-t-2 opacity-20"></div> <div class="absolute top-0 right-0 w-32 h-32 border-r-2 border-t-2 opacity-20"></div> <div class="absolute bottom-0 left-0 w-32 h-32 border-l-2 border-b-2 opacity-20"></div> <div class="absolute bottom-0 right-0 w-32 h-32 border-r-2 border-b-2 opacity-20"></div></div>`);function wr(i,s){Re(s,!1);const[p,g]=Ee(),d=()=>Ve(Ze,"$page",p),$=P(),a=P(),u=P(),r=P();let D=P(),E=P(),j=P();const oe={404:{icon:te,title:"Blueprint Not Found",description:"It seems the architectural plans you're looking for have been moved to another location. Let's help you find your way back.",color:"#56AAB7"},403:{icon:tr,title:"Access Restricted",description:"This area is under construction and requires special access. Please ensure you have the proper permissions.",color:"#F59E0B"},500:{icon:rr,title:"Foundation Issue",description:"We're experiencing some structural problems with our server. Our team is working to reinforce the foundation.",color:"#EF4444"},default:{icon:or,title:"Construction Zone",description:"We've encountered an unexpected issue. Our architectural team is investigating the problem.",color:"#6B7280"}};Se(()=>{const t=Ue.timeline();t.fromTo(e(E),{opacity:0,scale:.8,y:50},{opacity:1,scale:1,y:0,duration:1,ease:"power4.out"}),e(j)&&e(j).children&&t.fromTo(e(j).children,{opacity:0,y:30},{opacity:1,y:0,duration:.8,stagger:.1,ease:"power3.out"},"-=0.5");const o=e(D).querySelectorAll(".blueprint-line");t.fromTo(o,{scaleX:0,transformOrigin:"left center"},{scaleX:1,duration:1,stagger:.2,ease:"power2.inOut"},"-=1")}),W(()=>d(),()=>{A($,d().status===404)}),W(()=>d(),()=>{A(a,d().status||500)}),W(()=>d(),()=>{var t;A(u,((t=d().error)==null?void 0:t.message)||"An unexpected error occurred")}),W(()=>e(a),()=>{A(r,oe[e(a)]||oe.default)}),Le(),qe();var R=ur();He(t=>{var o=sr();C(()=>We.title=`${e(a)??""} - ${e(r),n(()=>e(r).title)??""} | 2WATUJU Architecture`),h(t,o)});var ae=v(l(R),2),se=v(ae,2),ne=v(se,2),ie=v(ne,2);{var me=t=>{var o=nr(),b=y(o),m=l(b);te(m,{size:200,get style(){return`color: ${e(r),n(()=>e(r).color)??""}`}}),c(b);var O=v(b,2),Be=l(O);te(Be,{size:150,get style(){return`color: ${e(r),n(()=>e(r).color)??""}`}}),c(O),h(t,o)},fe=t=>{var o=ir(),b=l(o);ge(b,()=>e(r).icon,(m,O)=>{O(m,{size:150,get style(){return`color: ${e(r),n(()=>e(r).color)??""}`}})}),c(o),h(t,o)};q(ie,t=>{e($)?t(me):t(fe,!1)})}var V=v(ie,2),S=l(V),L=l(S),he=l(L,!0);c(L),c(S),re(S,t=>A(E,t),()=>e(E));var X=v(S,2),U=l(X),Y=l(U),$e=l(Y);ge($e,()=>e(r).icon,(t,o)=>{o(t,{size:32})}),c(Y),c(U);var Z=v(U,2),J=l(Z),be=l(J,!0);c(J);var Q=v(J,2),ye=l(Q,!0);c(Q);var _e=v(Q,2);{var xe=t=>{var o=lr(),b=l(o),m=l(b,!0);c(b),c(o),C(()=>I(m,e(u))),h(t,o)};q(_e,t=>{!e($)&&e(u)&&t(xe)})}c(Z);var G=v(Z,2),le=l(G),ce=v(le,2),we=v(ce,2);c(G);var K=v(G,2),H=l(K),ke=l(H);Qe(ke,{size:20}),F(2),c(H);var ze=v(H,2);{var Ne=t=>{var o=cr(),b=v(l(o),2);Je(b,{size:20,class:"rotate-180"}),c(o),C(()=>f(o,`border-color: ${e(r),n(()=>e(r).color)??""}; color: ${e(r),n(()=>e(r).color)??""};`)),N("mouseenter",o,m=>{m.currentTarget.style.backgroundColor=e(r).color,m.currentTarget.style.color="white"}),N("mouseleave",o,m=>{m.currentTarget.style.backgroundColor="transparent",m.currentTarget.style.color=e(r).color}),h(t,o)},Te=t=>{var o=dr();o.__click=[ar];var b=l(o);er(b,{size:20}),F(2),c(o),C(()=>f(o,`border-color: ${e(r),n(()=>e(r).color)??""}; color: ${e(r),n(()=>e(r).color)??""};`)),N("mouseenter",o,m=>{m.currentTarget.style.backgroundColor=e(r).color,m.currentTarget.style.color="white"}),N("mouseleave",o,m=>{m.currentTarget.style.backgroundColor="transparent",m.currentTarget.style.color=e(r).color}),h(t,o)};q(ze,t=>{e($)?t(Ne):t(Te,!1)})}c(K);var de=v(K,2),ee=v(l(de),2),M=l(ee),Pe=l(M);Ke(Pe,{size:16}),F(2),c(M);var B=v(M,4),Ae=l(B);Ge(Ae,{size:16}),F(2),c(B),c(ee);var Me=v(ee,2);{var Ce=t=>{var o=vr(),b=l(o);c(o),C(m=>I(b,`Error Code: ${e(a)??""} | Timestamp: ${m??""}`),[()=>n(()=>new Date().toLocaleString())],Fe),h(t,o)};q(Me,t=>{e($)||t(Ce)})}c(de),c(X),re(X,t=>A(j,t),()=>e(j)),c(V);var ve=v(V,2),ue=v(ve,2),pe=v(ue,2),je=v(pe,2);c(R),re(R,t=>A(D,t),()=>e(D)),C(()=>{f(ae,`top: 20%; --line-color: ${e(r),n(()=>e(r).color)??""}30;`),f(se,`top: 50%; --line-color: ${e(r),n(()=>e(r).color)??""}30;`),f(ne,`top: 80%; --line-color: ${e(r),n(()=>e(r).color)??""}30;`),De(L,"data-number",e(a)),f(L,`--error-color: ${e(r),n(()=>e(r).color)??""}`),I(he,e(a)),f(Y,`background-color: ${e(r),n(()=>e(r).color)??""}20; color: ${e(r),n(()=>e(r).color)??""};`),I(be,(e(r),n(()=>e(r).title))),I(ye,(e(r),n(()=>e(r).description))),f(le,`background-image: linear-gradient(to right, transparent, ${e(r),n(()=>e(r).color)??""}, transparent);`),f(ce,`background-color: ${e(r),n(()=>e(r).color)??""};`),f(we,`background-image: linear-gradient(to right, transparent, ${e(r),n(()=>e(r).color)??""}, transparent);`),f(H,`background-color: ${e(r),n(()=>e(r).color)??""};`),f(M,`hover:color: ${e(r),n(()=>e(r).color)??""};`),f(B,`hover:color: ${e(r),n(()=>e(r).color)??""};`),f(ve,`border-color: ${e(r),n(()=>e(r).color)??""};`),f(ue,`border-color: ${e(r),n(()=>e(r).color)??""};`),f(pe,`border-color: ${e(r),n(()=>e(r).color)??""};`),f(je,`border-color: ${e(r),n(()=>e(r).color)??""};`)}),N("mouseenter",M,t=>t.currentTarget.style.color=e(r).color),N("mouseleave",M,t=>t.currentTarget.style.color="#4B5563"),N("mouseenter",B,t=>t.currentTarget.style.color=e(r).color),N("mouseleave",B,t=>t.currentTarget.style.color="#4B5563"),h(i,R),Oe(),g()}Ie(["click"]);export{wr as component};
